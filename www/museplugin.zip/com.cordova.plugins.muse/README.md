cordova plugin rm com.cordova.plugins.muse
cordova plugin add ../CordovaMuse